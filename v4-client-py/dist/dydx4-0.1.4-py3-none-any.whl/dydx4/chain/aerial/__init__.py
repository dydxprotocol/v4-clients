
"""Cosmpy aerial module."""
